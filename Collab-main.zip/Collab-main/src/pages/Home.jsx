


const Home = () => {
    return (
        <h1>FelineFyn</h1>
    )
}

export default Home;

